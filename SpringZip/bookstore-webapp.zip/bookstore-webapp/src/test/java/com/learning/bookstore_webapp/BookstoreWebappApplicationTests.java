package com.learning.bookstore_webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
